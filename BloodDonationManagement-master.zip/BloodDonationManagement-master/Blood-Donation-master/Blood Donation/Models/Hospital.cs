﻿namespace Blood_Donation.Models
{
    public enum Hospital
    {
        RajHospital,
        ShubhamHospital,
        RamanHospital
    }
}