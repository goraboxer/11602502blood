﻿namespace Blood_Donation.Models
{
    public enum BloodGroup
    { 
        Select,
        A,
        B,
        AB,
        O
    }
}